document.getElementById("donorForm").addEventListener("submit", async function(event) {
    event.preventDefault();
    
    const formData = new FormData(this);
    const fullName = formData.get("fullName");
    const mobNum = formData.get("mobNum");
    const emailID = formData.get("emailID");
    const aadharNum = formData.get("aadharNum");
    const residentialAddress = formData.get("residentialAddress");

    const response = await fetch("/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            fullName,
            mobNum,
            emailID,
            aadharNum,
            residentialAddress
        })
    });

    const data = await response.json();
    document.getElementById("message").innerText = data.message;
});
