async function checkCompatibility() {
    const donorBloodType = document.getElementById('donorBloodType').value;
    const receiverBloodType = document.getElementById('receiverBloodType').value;

    const response = await fetch('/api/check-compatibility', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            donorBloodType: parseInt(donorBloodType),
            receiverBloodType: parseInt(receiverBloodType)
        })
    });

    const result = await response.json();
    const compatibilityResult = document.getElementById('compatibilityResult');
    if (result.success) {
        compatibilityResult.textContent = 'Blood Compatibility: Compatible';
    } else {
        compatibilityResult.textContent = 'Blood Compatibility: Not Compatible';
    }
}
