document.addEventListener('DOMContentLoaded', function () {
    // Connect to the contract ABI
    const contractABI = [
        {
            "constant": true,
            "inputs": [],
            "name": "bloodBagCount",
            "outputs": [{"name": "", "type": "uint256"}],
            "payable": false,
            "stateMutability": "view",
            "type": "function"
        },
        {
            "constant": true,
            "inputs": [{"name": "", "type": "uint256"}],
            "name": "bloodBags",
            "outputs": [
                {"name": "status", "type": "uint8"},
                {"name": "bloodBankID", "type": "uint256"},
                {"name": "bloodBankName", "type": "string"}
            ],
            "payable": false,
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "payable": false,
            "stateMutability": "nonpayable",
            "type": "constructor"
        },
        {
            "anonymous": false,
            "inputs": [
                {"indexed": true, "name": "bloodBagId", "type": "uint256"},
                {"indexed": false, "name": "bloodBankID", "type": "uint256"},
                {"indexed": false, "name": "bloodBankName", "type": "string"},
                {"indexed": false, "name": "status", "type": "string"}
            ],
            "name": "BloodBagFound",
            "type": "event"
        },
        {
            "constant": false,
            "inputs": [
                {"name": "bloodBagId", "type": "uint256"},
                {"name": "status", "type": "uint8"},
                {"name": "bloodBankID", "type": "uint256"},
                {"name": "bloodBankName", "type": "string"}
            ],
            "name": "addBloodBag",
            "outputs": [],
            "payable": false,
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "constant": false,
            "inputs": [],
            "name": "findBlood",
            "outputs": [],
            "payable": false,
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "constant": true,
            "inputs": [{"name": "_status", "type": "uint8"}],
            "name": "statusToString",
            "outputs": [{"name": "", "type": "string"}],
            "payable": false,
            "stateMutability": "pure",
            "type": "function"
        }
    ];

    const contractAddress = 'YOUR_CONTRACT_ADDRESS'; // Replace with your contract address

    const web3 = new Web3(window.ethereum);
    const contract = new web3.eth.Contract(contractABI, contractAddress);

    const bloodBagList = document.getElementById('bloodBagList');

    // Function to display blood bags
    async function displayBloodBags() {
        const bloodBagCount = await contract.methods.bloodBagCount().call();
        bloodBagList.innerHTML = '';

        for (let i = 0; i < bloodBagCount; i++) {
            const bloodBag = await contract.methods.bloodBags(i).call();
            const status = await contract.methods.statusToString(bloodBag.status).call();

            const bloodBagItem = document.createElement('div');
            bloodBagItem.classList.add('blood-bag');
            bloodBagItem.innerHTML = `
                <h3>Blood Bag ID: ${i}</h3>
                <p>Blood Bank ID: ${bloodBag.bloodBankID}</p>
                <p>Blood Bank Name: ${bloodBag.bloodBankName}</p>
                <p>Status: <span class="status">${status}</span></p>
            `;
            bloodBagList.appendChild(bloodBagItem);
        }
    }

    // Listen for BloodBagFound event and update UI
    contract.events.BloodBagFound({}, function (error, event) {
        if (!error) {
            displayBloodBags();
        } else {
            console.error(error);
        }
    });

    // Call the function to display blood bags
    displayBloodBags();
});
