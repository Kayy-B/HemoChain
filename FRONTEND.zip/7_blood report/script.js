const HealthCheckerContractAddress = 'CONTRACT_ADDRESS'; // Replace with your contract address
const HealthCheckerContractABI = [ // Replace with your contract ABI
    {
        "inputs": [
            {
                "internalType": "int256",
                "name": "hemoglobin",
                "type": "int256"
            }
        ],
        "name": "checkHemoglobin",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "pure",
        "type": "function"
    },
    // Add ABIs for other functions here
];

window.addEventListener('load', async () => {
    const web3 = new Web3(Web3.givenProvider || "http://localhost:8545"); // Connect to Ethereum network
    const contract = new web3.eth.Contract(HealthCheckerContractABI, HealthCheckerContractAddress);

    document.getElementById('hemoglobin').addEventListener('input', async (event) => {
        const value = event.target.value;
        const result = await contract.methods.checkHemoglobin(value).call(); // Call the smart contract function
        document.getElementById('hemoglobin-result').textContent = result;
    });

    // Add similar event listeners for other blood components
});
