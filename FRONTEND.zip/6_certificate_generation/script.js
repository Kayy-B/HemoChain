async function generateCertificate() {
    const userType = document.getElementById('userType').value;
    const donorID = document.getElementById('donorID').value;
    const receiverID = document.getElementById('receiverID').value;
    const date = document.getElementById('date').value;
    const fullName = document.getElementById('fullName').value;

    const response = await fetch('/api/generate-certificate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userType: parseInt(userType),
            donorID: donorID,
            receiverID: receiverID,
            date: date,
            fullName: fullName
        })
    });

    const result = await response.json();
    const certificateResult = document.getElementById('certificateResult');
    if (result.success) {
        certificateResult.textContent = result.certificate;
    } else {
        certificateResult.textContent = 'Error: ' + result.error;
    }
}
