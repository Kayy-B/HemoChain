const contractABI = [
    [
        {
            "inputs": [
                {
                    "internalType": "string",
                    "name": "gender",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "age",
                    "type": "uint256"
                },
                {
                    "internalType": "uint256",
                    "name": "weight",
                    "type": "uint256"
                },
                {
                    "internalType": "uint256",
                    "name": "height",
                    "type": "uint256"
                },
                {
                    "internalType": "uint256",
                    "name": "daysSinceLastDonation",
                    "type": "uint256"
                }
            ],
            "name": "checkEligibility",
            "outputs": [
                {
                    "internalType": "string",
                    "name": "",
                    "type": "string"
                }
            ],
            "stateMutability": "pure",
            "type": "function"
        }
    ]
];

const contractAddress = '0xE745FAa66bBB733e7FCbEf03aB54eBE1549d1e88'; // Replace with your contract address

const provider = new ethers.providers.JsonRpcProvider(); // Use your preferred provider

const contract = new ethers.Contract(contractAddress, contractABI, provider);

document.getElementById("checkEligibilityBtn").addEventListener("click", async function() {
    var gender = document.getElementById("gender").value;
    var age = parseInt(document.getElementById("age").value);
    var weight = parseInt(document.getElementById("weight").value);
    var height = parseInt(document.getElementById("height").value);
    var daysSinceLastDonation = parseInt(document.getElementById("daysSinceLastDonation").value);

    try {
        const eligibility = await contract.checkEligibility(gender, age, weight, height, daysSinceLastDonation);
        var resultDiv = document.getElementById("result");
        resultDiv.innerHTML = eligibility;
    } catch (error) {
        console.error('Error:', error);
    }
});
