document.getElementById("bloodBagForm").addEventListener("submit", async function(event) {
    event.preventDefault();
    
    const formData = new FormData(this);
    const donorID = formData.get("donorID");
    const bloodBankID = formData.get("bloodBankID");
    const collectionDate = formData.get("collectionDate");
    const expiryDate = formData.get("expiryDate");

    const response = await fetch("/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            donorID,
            bloodBankID,
            collectionDate,
            expiryDate
        })
    });

    const data = await response.json();
    document.getElementById("message").innerText = data.message;
});
